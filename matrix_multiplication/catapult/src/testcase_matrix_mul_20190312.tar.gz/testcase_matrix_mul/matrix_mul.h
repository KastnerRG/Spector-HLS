#ifndef MATRIX_MUL_H
#define MATRIX_MUL_H
#include <ac_channel.h>
#include <ac_fixed.h>
#include "params.h"

typedef ac_fixed<20, 8, true> dtype;

struct DATA_MEM {
	dtype data[MVAL*MVAL];
};

#endif
