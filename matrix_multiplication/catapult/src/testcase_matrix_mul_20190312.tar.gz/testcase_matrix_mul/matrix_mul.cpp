#include "params.h"
#include "matrix_mul.h"

#pragma design top
void matrix_mul(ac_channel<dtype> &A, dtype B[MVAL*MVAL], dtype C[MVAL*MVAL])
{
//PRAGMA_HLS(HLS array_partition variable=B factor=PARTITION_FACTOR block)
//PRAGMA_HLS(HLS array_partition variable=C factor=PARTITION_FACTOR block)
//#pragma HLS INTERFACE axis depth=50 port=A
	DATA_MEM mem;
  #ifndef __SYNTHESIS__
	while(A.available(MVAL*MVAL))
	#endif
	{
		LOAD_MEM_MAIN: for(unsigned i=0; i<MVAL*MVAL; i++){
			mem.data[i] = A.read();
		}
		loop1:for(int i=0;i<MVAL*MVAL;i=i+SUBDIM_X)
		{
	//PRAGMA_HLS(HLS UNROLL FACTOR=UNROLL_FACTOR1)
			loop2:for(int p=0;p<SUBDIM_X;p++)
			{
	//PRAGMA_HLS(HLS UNROLL FACTOR=UNROLL_FACTOR2)
				dtype temp;
				temp=mem.data[MVAL*i+p];
				int t=(i+p)>>int(Mlog);
				int r=(i+p)%MVAL;
				loop3:for(int j=0;j<MVAL;j=j+SUBDIM_Y)
				{
					loop4:for(int l=0;l<SUBDIM_Y;l++)
	//PRAGMA_HLS(HLS UNROLL FACTOR=UNROLL_FACTOR3)
						C[t*MVAL+j+l]=C[t*MVAL+j+l]+temp*B[r*MVAL+j+l];
				}
			}
		}
	}
}

