#ifndef PARAMS_H_
#define PARAMS_H_
#define rows 480
#define cols 640
#define TVAL rows*col*3
#define KNOB_WINDOW_SIZE_X 16
#define inner_unroll1 1
#define inner_unroll2 1
#define outer_unroll 1
#define partition_factor 2
#endif